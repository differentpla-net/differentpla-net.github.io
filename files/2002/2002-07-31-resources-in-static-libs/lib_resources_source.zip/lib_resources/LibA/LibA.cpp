#include "StdAfx.h"
#include "LibraryDialog.h"

void DoLibraryDialog()
{
    CLibraryDialog dlg;
    dlg.DoModal();
}
