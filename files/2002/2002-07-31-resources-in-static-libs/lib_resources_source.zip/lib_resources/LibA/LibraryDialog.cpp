// LibraryDialog.cpp : implementation file
//

#include "stdafx.h"
#include "liba.h"
#include "LibraryDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLibraryDialog dialog


CLibraryDialog::CLibraryDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CLibraryDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLibraryDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CLibraryDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLibraryDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLibraryDialog, CDialog)
	//{{AFX_MSG_MAP(CLibraryDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLibraryDialog message handlers
