void DoLibraryDialog();
