//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LibA.rc
//
#define IDD_LIBRARY_DIALOG              301
#define IDC_LIBRARY_EDIT                3001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        302
#define _APS_NEXT_COMMAND_VALUE         60001
#define _APS_NEXT_CONTROL_VALUE         3002
#define _APS_NEXT_SYMED_VALUE           301
#endif
#endif
