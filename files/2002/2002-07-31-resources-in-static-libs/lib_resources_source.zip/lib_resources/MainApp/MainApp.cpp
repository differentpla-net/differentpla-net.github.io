// MainApp.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MainApp.h"
#include "MainAppDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CMainAppApp, CWinApp)
    //{{AFX_MSG_MAP(CMainAppApp)
    //}}AFX_MSG
END_MESSAGE_MAP()

CMainAppApp::CMainAppApp()
{
}

CMainAppApp theApp;

BOOL CMainAppApp::InitInstance()
{
    CMainAppDlg dlg;
    m_pMainWnd = &dlg;
    int nResponse = dlg.DoModal();
    return FALSE;
}
