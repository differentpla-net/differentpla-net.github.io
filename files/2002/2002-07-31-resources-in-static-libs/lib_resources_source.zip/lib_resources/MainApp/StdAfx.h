// stdafx.h : include file for standard system include files,

#if !defined(AFX_STDAFX_H__56862756_F16E_4355_9161_CB8158DB5A09__INCLUDED_)
#define AFX_STDAFX_H__56862756_F16E_4355_9161_CB8158DB5A09__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_STDAFX_H__56862756_F16E_4355_9161_CB8158DB5A09__INCLUDED_)
