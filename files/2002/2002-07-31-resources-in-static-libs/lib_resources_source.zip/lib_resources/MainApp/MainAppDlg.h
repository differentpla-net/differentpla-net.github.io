// MainAppDlg.h : header file
//

#if !defined(AFX_MAINAPPDLG_H__A05EE574_6930_46FC_9565_E6A480681D7D__INCLUDED_)
#define AFX_MAINAPPDLG_H__A05EE574_6930_46FC_9565_E6A480681D7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

class CMainAppDlg : public CDialog
{
public:
    CMainAppDlg(CWnd* pParent = NULL);	// standard constructor

    //{{AFX_DATA(CMainAppDlg)
    enum { IDD = IDD_MAINAPP_DIALOG };
    //}}AFX_DATA

    //{{AFX_VIRTUAL(CMainAppDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CMainAppDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnApplicationDialog();
	afx_msg void OnLibraryDialog();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_MAINAPPDLG_H__A05EE574_6930_46FC_9565_E6A480681D7D__INCLUDED_)
