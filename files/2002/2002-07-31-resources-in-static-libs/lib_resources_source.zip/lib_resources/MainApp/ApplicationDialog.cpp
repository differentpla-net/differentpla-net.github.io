// ApplicationDialog.cpp : implementation file
//

#include "stdafx.h"
#include "MainApp.h"
#include "ApplicationDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CApplicationDialog dialog


CApplicationDialog::CApplicationDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CApplicationDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CApplicationDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CApplicationDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CApplicationDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CApplicationDialog, CDialog)
	//{{AFX_MSG_MAP(CApplicationDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CApplicationDialog message handlers
