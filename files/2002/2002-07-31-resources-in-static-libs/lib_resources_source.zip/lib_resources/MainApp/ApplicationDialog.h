#if !defined(AFX_APPLICATIONDIALOG_H__C2C6AEA1_9509_4731_BFF1_37646F644C0D__INCLUDED_)
#define AFX_APPLICATIONDIALOG_H__C2C6AEA1_9509_4731_BFF1_37646F644C0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ApplicationDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CApplicationDialog dialog

class CApplicationDialog : public CDialog
{
// Construction
public:
	CApplicationDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CApplicationDialog)
	enum { IDD = IDD_APPLICATION_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CApplicationDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CApplicationDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_APPLICATIONDIALOG_H__C2C6AEA1_9509_4731_BFF1_37646F644C0D__INCLUDED_)
