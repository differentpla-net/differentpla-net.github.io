// MainAppDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MainAppDlg.h"
#include "ApplicationDialog.h"
#include "../LibA/LibA.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMainAppDlg::CMainAppDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CMainAppDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CMainAppDlg)
    //}}AFX_DATA_INIT
}

void CMainAppDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CMainAppDlg)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMainAppDlg, CDialog)
    //{{AFX_MSG_MAP(CMainAppDlg)
    ON_BN_CLICKED(IDC_APPLICATION_DIALOG, OnApplicationDialog)
	ON_BN_CLICKED(IDC_LIBRARY_DIALOG, OnLibraryDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainAppDlg message handlers

BOOL CMainAppDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    return TRUE;
}

void CMainAppDlg::OnApplicationDialog() 
{
    CApplicationDialog dlg;
    dlg.DoModal();
}

void CMainAppDlg::OnLibraryDialog() 
{
    DoLibraryDialog();
}
