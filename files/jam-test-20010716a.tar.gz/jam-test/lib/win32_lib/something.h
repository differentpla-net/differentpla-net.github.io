/* something.h */

int something(const char *p);
