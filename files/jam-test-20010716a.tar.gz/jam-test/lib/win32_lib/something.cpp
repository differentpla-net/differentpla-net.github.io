/* something.cpp */

#include "something.h"
#include <string.h>

int something(const char *p)
{
    return strlen(p) + 42;
}
