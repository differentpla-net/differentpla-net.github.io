// mfc_exeDoc.cpp : implementation of the CMfc_exeDoc class
//

#include "stdafx.h"
#include "mfc_exe.h"

#include "mfc_exeDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeDoc

IMPLEMENT_DYNCREATE(CMfc_exeDoc, CDocument)

BEGIN_MESSAGE_MAP(CMfc_exeDoc, CDocument)
	//{{AFX_MSG_MAP(CMfc_exeDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeDoc construction/destruction

CMfc_exeDoc::CMfc_exeDoc()
{
	// TODO: add one-time construction code here

}

CMfc_exeDoc::~CMfc_exeDoc()
{
}

BOOL CMfc_exeDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMfc_exeDoc serialization

void CMfc_exeDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeDoc diagnostics

#ifdef _DEBUG
void CMfc_exeDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMfc_exeDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeDoc commands
