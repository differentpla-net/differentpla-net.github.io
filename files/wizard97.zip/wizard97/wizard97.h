/* wizard97.h
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#if !defined(AFX_WIZARD97_H__D21363E7_2F1C_4AD6_B472_DF1FC3793B0B__INCLUDED_)
#define AFX_WIZARD97_H__D21363E7_2F1C_4AD6_B472_DF1FC3793B0B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

class CWizard97App : public CWinApp
{
public:
    CWizard97App();

    //{{AFX_VIRTUAL(CWizard97App)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

    //{{AFX_MSG(CWizard97App)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_WIZARD97_H__D21363E7_2F1C_4AD6_B472_DF1FC3793B0B__INCLUDED_)
