/* CompletePage.h
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#ifndef COMPLETE_PAGE_H
#define COMPLETE_PAGE_H 1

#include "WizardPage.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CCompletePage dialog

class CCompletePage : public CWizardPage
{
    DECLARE_DYNCREATE(CCompletePage)

public:
    CCompletePage();
    ~CCompletePage();

    //{{AFX_DATA(CCompletePage)
    enum { IDD = IDD_COMPLETE_PAGE };
    //}}AFX_DATA

    //{{AFX_VIRTUAL(CCompletePage)
	public:
	virtual BOOL OnSetActive();
	virtual LRESULT OnWizardBack();
	protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CCompletePage)
    virtual BOOL OnInitDialog();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

#endif /* COMPLETE_PAGE_H */
