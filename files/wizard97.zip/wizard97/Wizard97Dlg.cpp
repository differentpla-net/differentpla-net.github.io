/* Wizard97Dlg.cpp
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "stdafx.h"
#include "Wizard97Dlg.h"
#include "VersionInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizard97Dlg

IMPLEMENT_DYNAMIC(CWizard97Dlg, CPropertySheetEx)

CWizard97Dlg::CWizard97Dlg(CWnd *pParentWnd, int iSelectPage, HBITMAP hbmWatermark, HPALETTE hpalWatermark, HBITMAP hbmHeader)
    : CPropertySheetEx(IDS_WIZARD_CAPTION, pParentWnd, iSelectPage, hbmWatermark, hpalWatermark, hbmHeader)
{
    AddPage(&m_welcomePage);
    AddPage(&m_middlePage);
    AddPage(&m_otherPage);
    AddPage(&m_completePage);

	SetWizardMode();

	if (SupportsWizard97())
		m_psh.dwFlags |= PSH_WIZARD97;
}

CWizard97Dlg::~CWizard97Dlg()
{
}

BEGIN_MESSAGE_MAP(CWizard97Dlg, CPropertySheetEx)
    //{{AFX_MSG_MAP(CWizard97Dlg)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWizard97Dlg message handlers
