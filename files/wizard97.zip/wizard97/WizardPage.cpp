/* WizardPage.cpp
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "stdafx.h"
#include "WizardPage.h"
#include "Wizard97Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizardPage property page

IMPLEMENT_DYNAMIC(CWizardPage, CPropertyPageEx)

CWizardPage::CWizardPage(UINT nIDTemplate, UINT nIDCaption, UINT nIDHeaderTitle, UINT nIDHeaderSubTitle)
    : CPropertyPageEx(nIDTemplate, nIDCaption, nIDHeaderTitle, nIDHeaderSubTitle)
{
    //{{AFX_DATA_INIT(CWizardPage)
    //}}AFX_DATA_INIT
}

CWizardPage::~CWizardPage()
{
}

void CWizardPage::DoDataExchange(CDataExchange* pDX)
{
    CPropertyPageEx::DoDataExchange(pDX);

    //{{AFX_DATA_MAP(CWizardPage)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWizardPage, CPropertyPageEx)
    //{{AFX_MSG_MAP(CWizardPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static void GetMessageBoxFont(LOGFONT *lf)
{
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);
	VERIFY(SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(ncm), &ncm, 0));
	*lf = ncm.lfMessageFont;
}

bool CWizardPage::CreateBoldFont(CFont *pFont)
{
	LOGFONT lf;
	GetMessageBoxFont(&lf);

	CDC *pDC = GetDC();
	lf.lfHeight = -MulDiv(12, GetDeviceCaps(pDC->m_hDC, LOGPIXELSY), 72);
	ReleaseDC(pDC);

	lf.lfWeight = FW_BOLD;

	if (pFont->CreateFontIndirect(&lf))
		return true;
	return false;
}

void CWizardPage::InflictBoldFont(UINT nIDC)
{
	CWnd *pWnd = GetDlgItem(nIDC);
	if (pWnd)
		pWnd->SetFont(&m_boldFont);
}

CWizard97Dlg *CWizardPage::GetParent()
{
	CWnd *pParent = CPropertyPageEx::GetParent();
	CWizard97Dlg *pWizard = static_cast<CWizard97Dlg *>(pParent);
	return pWizard;
}

void CWizardPage::SetWizardButtons(DWORD dwFlags)
{
	GetParent()->SetWizardButtons(dwFlags);
}

/////////////////////////////////////////////////////////////////////////////
// CWizardPage message handlers

BOOL CWizardPage::OnInitDialog() 
{
	CPropertyPageEx::OnInitDialog();

	CreateBoldFont(&m_boldFont);

	return TRUE;
}
