/* wizard97.cpp
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "stdafx.h"
#include "wizard97.h"
#include "Wizard97Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizard97App

BEGIN_MESSAGE_MAP(CWizard97App, CWinApp)
    //{{AFX_MSG_MAP(CWizard97App)
    //}}AFX_MSG
    ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

CWizard97App::CWizard97App()
{
}

CWizard97App theApp;

BOOL CWizard97App::InitInstance()
{
    InitCommonControls();

    HBITMAP hbmWatermark = ::LoadBitmap(AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_WATERMARK));
    HPALETTE hpalWatermark = NULL;
    HBITMAP hbmHeader = ::LoadBitmap(AfxGetResourceHandle(), MAKEINTRESOURCE(IDB_HEADER));

    CWizard97Dlg dlg(NULL, 0, hbmWatermark, hpalWatermark, hbmHeader);
    m_pMainWnd = &dlg;
    UINT_PTR nResponse = dlg.DoModal();

    // Since the dialog has been closed, return FALSE so that we exit the
    //  application, rather than start the application's message pump.
    return FALSE;
}
