/* MiddlePage.cpp
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "StdAfx.h"
#include "MiddlePage.h"

IMPLEMENT_DYNCREATE(CMiddlePage, CWizardPage)

/////////////////////////////////////////////////////////////////////////////
// CMiddlePage property page

CMiddlePage::CMiddlePage()
    : CWizardPage(CMiddlePage::IDD, IDS_MIDDLE_PAGE_CAPTION, IDS_MIDDLE_PAGE_TITLE, IDS_MIDDLE_PAGE_SUBTITLE)
{
    //{{AFX_DATA_INIT(CMiddlePage)
    m_bShowAdvancedOptions = FALSE;
    //}}AFX_DATA_INIT
}

CMiddlePage::~CMiddlePage()
{
}

void CMiddlePage::DoDataExchange(CDataExchange* pDX)
{
    CWizardPage::DoDataExchange(pDX);

    //{{AFX_DATA_MAP(CMiddlePage)
    DDX_Check(pDX, IDC_SHOW_ADVANCED_OPTIONS, m_bShowAdvancedOptions);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMiddlePage, CWizardPage)
    //{{AFX_MSG_MAP(CMiddlePage)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CMiddlePage::OnSetActive() 
{
	if (!CWizardPage::OnSetActive())
		return FALSE;

	SetWizardButtons(PSWIZB_BACK|PSWIZB_NEXT);

	return TRUE;
}

LRESULT CMiddlePage::OnWizardNext() 
{
	if (!UpdateData(TRUE))
		return -1;

	if (!m_bShowAdvancedOptions)
		return IDD_COMPLETE_PAGE;

	return CWizardPage::OnWizardNext();
}
