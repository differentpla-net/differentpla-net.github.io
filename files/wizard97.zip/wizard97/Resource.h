//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wizard97.rc
//
#define IDD_WIZARD97_DIALOG             102
#define IDD_WELCOME_PAGE                104
#define IDS_COMPLETE_PAGE_CAPTION       104
#define IDD_MIDDLE_PAGE                 105
#define IDD_COMPLETE_PAGE               106
#define IDS_MIDDLE_PAGE_CAPTION         107
#define IDD_OTHER_PAGE                  107
#define IDS_MIDDLE_PAGE_TITLE           108
#define IDS_MIDDLE_PAGE_SUBTITLE        109
#define IDS_WELCOME_PAGE_CAPTION        110
#define IDS_WIZARD_CAPTION              113
#define IDS_OTHER_PAGE_CAPTION          114
#define IDS_OTHER_PAGE_TITLE            115
#define IDS_OTHER_PAGE_SUBTITLE         116
#define IDR_MAINFRAME                   128
#define IDB_WATERMARK                   129
#define IDB_HEADER                      130
#define IDC_TITLE                       1000
#define IDC_SHOW_ADVANCED_OPTIONS       1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
