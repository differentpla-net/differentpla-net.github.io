/* WizardPage.h
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#if !defined(AFX_WIZARDPAGE_H__3966D7D9_F0E5_408C_9993_26897D6905E1__INCLUDED_)
#define AFX_WIZARDPAGE_H__3966D7D9_F0E5_408C_9993_26897D6905E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CWizardPage dialog

class CWizard97Dlg;

class CWizardPage : public CPropertyPageEx
{
    CFont m_boldFont;

    DECLARE_DYNAMIC(CWizardPage)

public:
    CWizardPage(UINT nIDTemplate, UINT nIDCaption = 0, UINT nIDHeaderTitle = 0, UINT nIDHeaderSubTitle = 0);
    ~CWizardPage();

    //{{AFX_DATA(CWizardPage)
    //}}AFX_DATA

    //{{AFX_VIRTUAL(CWizardPage)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CWizardPage)
    virtual BOOL OnInitDialog();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()

private:
    bool CreateBoldFont(CFont *pFont);

protected:
    void InflictBoldFont(UINT nIDC);

    CWizard97Dlg *GetParent();
    void SetWizardButtons(DWORD dwFlags);
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_WIZARDPAGE_H__3966D7D9_F0E5_408C_9993_26897D6905E1__INCLUDED_)
