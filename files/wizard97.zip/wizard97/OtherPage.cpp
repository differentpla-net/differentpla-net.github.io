/* OtherPage.cpp
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "StdAfx.h"
#include "OtherPage.h"

IMPLEMENT_DYNCREATE(COtherPage, CWizardPage)

/////////////////////////////////////////////////////////////////////////////
// COtherPage property page

COtherPage::COtherPage()
    : CWizardPage(COtherPage::IDD, IDS_OTHER_PAGE_CAPTION, IDS_OTHER_PAGE_TITLE, IDS_OTHER_PAGE_SUBTITLE)
{
    //{{AFX_DATA_INIT(COtherPage)
    //}}AFX_DATA_INIT
}

COtherPage::~COtherPage()
{
}

void COtherPage::DoDataExchange(CDataExchange* pDX)
{
    CWizardPage::DoDataExchange(pDX);

    //{{AFX_DATA_MAP(COtherPage)
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COtherPage, CWizardPage)
    //{{AFX_MSG_MAP(COtherPage)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL COtherPage::OnSetActive() 
{
	if (!CWizardPage::OnSetActive())
		return FALSE;

	SetWizardButtons(PSWIZB_BACK|PSWIZB_NEXT);

	return TRUE;
}
