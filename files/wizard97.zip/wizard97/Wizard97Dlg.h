/* Wizard97Dlg.h
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#ifndef __WIZARD97DLG_H__
#define __WIZARD97DLG_H__

#include "WelcomePage.h"
#include "MiddlePage.h"
#include "OtherPage.h"
#include "CompletePage.h"

/////////////////////////////////////////////////////////////////////////////
// CWizard97Dlg

class CWizard97Dlg : public CPropertySheetEx
{
    DECLARE_DYNAMIC(CWizard97Dlg)

public:
    CWizard97Dlg(CWnd *pParentWnd, int iSelectPage, HBITMAP hbmWatermark, HPALETTE hpalWatermark, HBITMAP hbmHeader);
    virtual ~CWizard97Dlg();

public:
    CWelcomePage m_welcomePage;
    CMiddlePage m_middlePage;
    COtherPage m_otherPage;
    CCompletePage m_completePage;

    //{{AFX_VIRTUAL(CWizard97Dlg)
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CWizard97Dlg)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// __WIZARD97DLG_H__
