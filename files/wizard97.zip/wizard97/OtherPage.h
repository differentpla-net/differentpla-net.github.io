/* OtherPage.h
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "WizardPage.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// COtherPage dialog

class COtherPage : public CWizardPage
{
    DECLARE_DYNCREATE(COtherPage)

public:
    COtherPage();
    ~COtherPage();

    //{{AFX_DATA(COtherPage)
    enum { IDD = IDD_OTHER_PAGE };
    //}}AFX_DATA

    //{{AFX_VIRTUAL(COtherPage)
    public:
    virtual BOOL OnSetActive();
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(COtherPage)
    //}}AFX_MSG

    DECLARE_MESSAGE_MAP()
};

