/* CompletePage.cpp
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "StdAfx.h"
#include "CompletePage.h"
#include "Wizard97Dlg.h"

IMPLEMENT_DYNCREATE(CCompletePage, CWizardPage)

/////////////////////////////////////////////////////////////////////////////
// CCompletePage property page

CCompletePage::CCompletePage()
    : CWizardPage(CCompletePage::IDD, IDS_COMPLETE_PAGE_CAPTION)
{
    //{{AFX_DATA_INIT(CCompletePage)
    //}}AFX_DATA_INIT

    m_psp.dwFlags |= PSP_HIDEHEADER;
}

CCompletePage::~CCompletePage()
{
}

void CCompletePage::DoDataExchange(CDataExchange* pDX)
{
    CWizardPage::DoDataExchange(pDX);

    //{{AFX_DATA_MAP(CCompletePage)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCompletePage, CWizardPage)
    //{{AFX_MSG_MAP(CCompletePage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CCompletePage::OnInitDialog() 
{
	CWizardPage::OnInitDialog();

	InflictBoldFont(IDC_TITLE);
	return TRUE;
}

BOOL CCompletePage::OnSetActive() 
{
	if (!CWizardPage::OnSetActive())
		return FALSE;

	SetWizardButtons(PSWIZB_BACK|PSWIZB_FINISH);
	return TRUE;
}

LRESULT CCompletePage::OnWizardBack() 
{
	if (!GetParent()->m_middlePage.m_bShowAdvancedOptions)
		return IDD_MIDDLE_PAGE;

	return CWizardPage::OnWizardBack();
}
