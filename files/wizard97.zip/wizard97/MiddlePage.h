/* MiddlePage.h
 *
 * Copyright (C) 2003 Roger Lipscombe
 *     http://www.differentpla.net/~roger/
 */

#include "WizardPage.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CMiddlePage dialog

class CMiddlePage : public CWizardPage
{
    DECLARE_DYNCREATE(CMiddlePage)

public:
    CMiddlePage();
    ~CMiddlePage();

    //{{AFX_DATA(CMiddlePage)
    enum { IDD = IDD_MIDDLE_PAGE };
    BOOL	m_bShowAdvancedOptions;
    //}}AFX_DATA

    //{{AFX_VIRTUAL(CMiddlePage)
    public:
    virtual BOOL OnSetActive();
    virtual LRESULT OnWizardNext();
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CMiddlePage)
    //}}AFX_MSG

    DECLARE_MESSAGE_MAP()
};

