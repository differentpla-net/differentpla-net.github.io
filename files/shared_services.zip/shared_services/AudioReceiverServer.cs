using System;

namespace AudioReceiverServer
{
	/// <summary>
	/// Summary description for AudioReceiverServer.
	/// </summary>
	public class AudioReceiverServer
	{
		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] servicesToRun;
	
			servicesToRun = new System.ServiceProcess.ServiceBase[] { new DhcpService(), new ServiceDiscoveryService(), new NfsService(),  new HttpService() };

			System.ServiceProcess.ServiceBase.Run(servicesToRun);
		}
	}
}
