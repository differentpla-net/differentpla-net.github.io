// mfc_exeView.cpp : implementation of the CMfc_exeView class
//

#include "stdafx.h"
#include "mfc_exe.h"

#include "mfc_exeDoc.h"
#include "mfc_exeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeView

IMPLEMENT_DYNCREATE(CMfc_exeView, CView)

BEGIN_MESSAGE_MAP(CMfc_exeView, CView)
	//{{AFX_MSG_MAP(CMfc_exeView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeView construction/destruction

CMfc_exeView::CMfc_exeView()
{
	// TODO: add construction code here

}

CMfc_exeView::~CMfc_exeView()
{
}

BOOL CMfc_exeView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeView drawing

void CMfc_exeView::OnDraw(CDC* pDC)
{
	CMfc_exeDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeView printing

BOOL CMfc_exeView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMfc_exeView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMfc_exeView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeView diagnostics

#ifdef _DEBUG
void CMfc_exeView::AssertValid() const
{
	CView::AssertValid();
}

void CMfc_exeView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMfc_exeDoc* CMfc_exeView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMfc_exeDoc)));
	return (CMfc_exeDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMfc_exeView message handlers
