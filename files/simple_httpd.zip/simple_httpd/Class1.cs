using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Collections.Specialized;

namespace httpd
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			int port = 8081;
			IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, port);
			System.Console.WriteLine("Listening on {0}", endPoint.ToString());

			TcpListener listener = new TcpListener(endPoint);
			listener.Start();

			for (;;)
			{
				System.Console.WriteLine("Accepting connections...");

				Socket client = listener.AcceptSocket();
				ThreadPool.QueueUserWorkItem(new WaitCallback(ClientConnectCallback), client);
			}
		}

		static void ClientConnectCallback(object state)
		{
			Socket client = (Socket)state;

			System.Console.WriteLine("Accepted connection from {0}", client.RemoteEndPoint.ToString());

			NetworkStream stream = new NetworkStream(client);
			TextReader reader = new StreamReader(stream);
			TextWriter writer = new StreamWriter(stream);

			// Get the request.
			string request = reader.ReadLine();
			System.Console.WriteLine("Client request: {0}", request);

			// The request is formatted as, e.g., GET / HTTP/1.1
			string[] parts = request.Split(" ".ToCharArray());
			string method = parts[0];
			string request_uri = parts[1];
			string request_ver = parts[2];

			System.Console.WriteLine("method: '{0}', request_uri: '{1}', request_ver: '{2}'", method, request_uri, request_ver);

			// Read the headers.
			StringDictionary headers = new StringDictionary();
			for (;;)
			{
				string header = reader.ReadLine();
				if (header == "")
					break;

				int pos = header.IndexOf(":");
				string field_name = header.Substring(0, pos);
				string field_value = header.Substring(pos+1).TrimStart(" ".ToCharArray());
				System.Console.WriteLine("field_name: '{0}', field_value: '{1}'", field_name, field_value);

				headers.Add(field_name, field_value);
			}

			// (Since we don't support POST, we don't need to read any body, except possibly to skip it).
			// (Since we're Connection: close, we don't need to skip the body -- it'll get discarded when the socket is closed).

			writer.WriteLine("HTTP/1.0 200 OK");
			writer.WriteLine("Content-Type: text/html");
			writer.WriteLine("Connection: close");
			writer.WriteLine("Server: SimpleWebserver/0.1");
			writer.WriteLine("");
			writer.Flush();

			System.Console.WriteLine("Sleeping...");
			Thread.Sleep(1000);
			writer.WriteLine("<html>");
			writer.WriteLine("<head><style>body { font-family: Verdana; font-size:10pt; }</style></head>");
			writer.WriteLine("<body>");
			writer.WriteLine("<h1>Simple Webserver</h1>");
			writer.WriteLine("<pre>");
			IDictionaryEnumerator enumerator = (IDictionaryEnumerator)headers.GetEnumerator();
			while (enumerator.MoveNext())
				writer.WriteLine("{0}: {1}", enumerator.Key, enumerator.Value);

			writer.WriteLine("</pre>");
			writer.WriteLine("</body>");
			writer.WriteLine("</html>");
			writer.Flush();

			System.Console.WriteLine("Closed connection to {0}", client.RemoteEndPoint.ToString());

			client.Close();
		}
	}
}
