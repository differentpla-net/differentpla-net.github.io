// mfc_exeView.h : interface of the CMfc_exeView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MFC_EXEVIEW_H__197D826B_B399_4113_B752_01005BC71F95__INCLUDED_)
#define AFX_MFC_EXEVIEW_H__197D826B_B399_4113_B752_01005BC71F95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMfc_exeView : public CView
{
protected: // create from serialization only
	CMfc_exeView();
	DECLARE_DYNCREATE(CMfc_exeView)

// Attributes
public:
	CMfc_exeDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMfc_exeView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMfc_exeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMfc_exeView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in mfc_exeView.cpp
inline CMfc_exeDoc* CMfc_exeView::GetDocument()
   { return (CMfc_exeDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFC_EXEVIEW_H__197D826B_B399_4113_B752_01005BC71F95__INCLUDED_)
