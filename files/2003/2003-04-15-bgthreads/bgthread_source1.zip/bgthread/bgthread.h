// bgthread.h : main header file for the BGTHREAD application
//

#if !defined(AFX_BGTHREAD_H__AB71B597_1A19_4609_B5AC_E102F060E920__INCLUDED_)
#define AFX_BGTHREAD_H__AB71B597_1A19_4609_B5AC_E102F060E920__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CBgthreadApp:
// See bgthread.cpp for the implementation of this class
//

class CBgthreadApp : public CWinApp
{
public:
	CBgthreadApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBgthreadApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBgthreadApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BGTHREAD_H__AB71B597_1A19_4609_B5AC_E102F060E920__INCLUDED_)
