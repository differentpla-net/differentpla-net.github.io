// bgthreadDlg.h : header file
//

#if !defined(AFX_BGTHREADDLG_H__4C456825_3099_4459_BE3A_DCAFE3AF9F4A__INCLUDED_)
#define AFX_BGTHREADDLG_H__4C456825_3099_4459_BE3A_DCAFE3AF9F4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBgthreadDlg : public CDialog
{
public:
    CBgthreadDlg(CWnd* pParent = NULL);	// standard constructor

    //{{AFX_DATA(CBgthreadDlg)
	enum { IDD = IDD_BGTHREAD_DIALOG };
	//}}AFX_DATA

    //{{AFX_VIRTUAL(CBgthreadDlg)
    //}}AFX_VIRTUAL

protected:
    //{{AFX_MSG(CBgthreadDlg)
    afx_msg void OnForeground();
	afx_msg void OnForegroundHourglass();
	afx_msg void OnForegroundProgress();
	//}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_BGTHREADDLG_H__4C456825_3099_4459_BE3A_DCAFE3AF9F4A__INCLUDED_)
