#include "StdAfx.h"
#include "task.h"

void Task::Run()
{
    // Pretend to do some work.
    DWORD startTicks = GetTickCount();

    const int MAX_ITERATIONS = 10;
    for (int i = 0; i < MAX_ITERATIONS; ++i)
    {
	TRACE("Iteration %d, ms = %d\n", i, GetTickCount() - startTicks);
	ReportProgress(i, MAX_ITERATIONS);
	Sleep(1000);
    }
    
    ReportProgress(MAX_ITERATIONS, MAX_ITERATIONS);
}
