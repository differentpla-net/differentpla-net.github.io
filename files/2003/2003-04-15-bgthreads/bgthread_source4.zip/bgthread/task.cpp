#include "StdAfx.h"
#include "task.h"

void Task::Run()
{
    // Pretend to do some work.
    const int MAX_ITERATIONS = 10;
    for (int i = 0; i < MAX_ITERATIONS; ++i)
    {
	DWORD startTicks = GetTickCount();
	ReportProgress(i, MAX_ITERATIONS);
	Sleep(1000);
	
	DWORD iterationTicks = GetTickCount() - startTicks;
	if (iterationTicks > 1200)
	    TRACE("Warning: Iteration %d took too long (%d ms)\n", i, iterationTicks);
	else
	    TRACE("Iteration %d took %d ms\n", i, iterationTicks);
    }
    
    ReportProgress(MAX_ITERATIONS, MAX_ITERATIONS);
    ReportComplete();
}
