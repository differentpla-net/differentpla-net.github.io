#include "thread.h"

class TaskObserver;

class TaskThread : public Thread
{
    TaskObserver *m_pObserver;

public:
    TaskThread(TaskObserver *pObserver)
	: m_pObserver(pObserver)
    {
    }

    virtual unsigned Run();
};
