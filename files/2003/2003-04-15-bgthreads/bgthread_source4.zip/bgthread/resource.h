//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bgthread.rc
//
#define IDD_BGTHREAD_DIALOG             102
#define CG_IDD_PROGRESS                 103
#define CG_IDS_PROGRESS_CAPTION         104
#define IDR_MAINFRAME                   128
#define IDC_FOREGROUND                  1001
#define IDC_FOREGROUND_HOURGLASS        1002
#define CG_IDC_PROGDLG_PROGRESS         1003
#define IDC_FOREGROUND_PROGRESS         1003
#define IDC_BACKGROUND                  1004
#define IDC_BACKGROUND_JOIN             1005
#define IDC_BACKGROUND_BUSY             1006
#define IDC_BACKGROUND_MODAL            1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
