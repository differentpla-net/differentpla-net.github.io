#include "StdAfx.h"
#include "task_thread.h"
#include "task.h"

unsigned TaskThread::Run()
{
    TRACE("TaskThread starts\n");

    Task task(m_pObserver);
    task.Run();

    TRACE("TaskThread exits\n");
    
    return 0;
}
