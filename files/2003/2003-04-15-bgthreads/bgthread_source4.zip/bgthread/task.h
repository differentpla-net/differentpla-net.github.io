class TaskObserver;

class Task
{
    TaskObserver *m_pObserver;

public:
    Task(TaskObserver *pObserver)
	: m_pObserver(pObserver) { }

    void Run();

private:
    inline void ReportProgress(int current, int maximum);
    inline void ReportComplete();
};

class TaskObserver
{
public:
    virtual void OnProgress(int current, int maximum) = 0;
    virtual void OnComplete() = 0;
};

inline void Task::ReportProgress(int current, int maximum)
{
    if (m_pObserver)
	m_pObserver->OnProgress(current, maximum);
}

inline void Task::ReportComplete()
{
    if (m_pObserver)
	m_pObserver->OnComplete();
}
