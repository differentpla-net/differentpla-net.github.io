// bgthreadDlg.cpp : implementation file
//

#include "stdafx.h"
#include "bgthread.h"
#include "bgthreadDlg.h"
#include "ProgDlg.h"
#include "task_thread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CBgthreadDlg::CBgthreadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBgthreadDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CBgthreadDlg)
    //}}AFX_DATA_INIT
}

BEGIN_MESSAGE_MAP(CBgthreadDlg, CDialog)
    //{{AFX_MSG_MAP(CBgthreadDlg)
    ON_BN_CLICKED(IDC_FOREGROUND, OnForeground)
	ON_BN_CLICKED(IDC_FOREGROUND_HOURGLASS, OnForegroundHourglass)
	ON_BN_CLICKED(IDC_FOREGROUND_PROGRESS, OnForegroundProgress)
	ON_BN_CLICKED(IDC_BACKGROUND, OnBackground)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BACKGROUND_JOIN, OnBackgroundJoin)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CBgthreadDlg::OnForeground()
{
    Task task(NULL);
    task.Run();
}

void CBgthreadDlg::OnForegroundHourglass() 
{
    CWaitCursor wait;

    Task task(NULL); //&dlg);
    task.Run();
}

void CBgthreadDlg::OnForegroundProgress() 
{
    CProgressDlg dlg;
    dlg.Create(this);
    
    Task task(&dlg);
    task.Run();
    
    dlg.DestroyWindow();
}

void CBgthreadDlg::OnBackground() 
{
    // Run on a background thread.  Don't wait for the thread to exit.
    TaskThread *t = new TaskThread;
    t->Start();
}

void CBgthreadDlg::OnBackgroundJoin() 
{
    CWaitCursor wait;

    TaskThread *t = new TaskThread;
    t->Start();

    // Wait for it to finish
    t->Join();
    delete t;
}
