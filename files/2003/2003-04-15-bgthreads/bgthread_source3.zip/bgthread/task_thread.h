#include "thread.h"

class TaskThread : public Thread
{
public:
    virtual unsigned Run();
};
