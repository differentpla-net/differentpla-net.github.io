#include "StdAfx.h"
#include "task_thread.h"
#include "task.h"

unsigned TaskThread::Run()
{
    Task task(NULL);
    task.Run();
    
    return 0;
}
