class TaskObserver;

class Task
{
    TaskObserver *m_pObserver;

public:
    Task(TaskObserver *pObserver)
	: m_pObserver(pObserver) { }

    void Run();

private:
    inline void ReportProgress(int current, int maximum);
};

class TaskObserver
{
public:
    virtual void OnProgress(int current, int maximum) = 0;
};

inline void Task::ReportProgress(int current, int maximum)
{
    if (m_pObserver)
	m_pObserver->OnProgress(current, maximum);
}
