// bgthreadDlg.cpp : implementation file
//

#include "stdafx.h"
#include "bgthread.h"
#include "bgthreadDlg.h"
#include "ProgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CBgthreadDlg::CBgthreadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBgthreadDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CBgthreadDlg)
    //}}AFX_DATA_INIT
}

BEGIN_MESSAGE_MAP(CBgthreadDlg, CDialog)
    //{{AFX_MSG_MAP(CBgthreadDlg)
    ON_BN_CLICKED(IDC_FOREGROUND, OnForeground)
	ON_BN_CLICKED(IDC_FOREGROUND_HOURGLASS, OnForegroundHourglass)
	ON_BN_CLICKED(IDC_FOREGROUND_PROGRESS, OnForegroundProgress)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BACKGROUND, OnBackground)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CBgthreadDlg::OnForeground()
{
    Task task(NULL);
    task.Run();
}

void CBgthreadDlg::OnForegroundHourglass() 
{
    CWaitCursor wait;

    Task task(NULL); //&dlg);
    task.Run();
}

void CBgthreadDlg::OnForegroundProgress() 
{
    CProgressDlg dlg;
    dlg.Create(this);
    
    Task task(&dlg);
    task.Run();
    
    dlg.DestroyWindow();
}

#include <process.h>

class Thread
{
    HANDLE m_hThread;
    unsigned m_idThread;

public:
    Thread()
	: m_hThread(NULL), m_idThread(0)
    {
    }

    bool Start()
    {
	unsigned threadId;
	HANDLE hThread = (HANDLE)_beginthreadex(NULL, 0, StaticThreadRoutine, this, CREATE_SUSPENDED, &threadId);
	if (!hThread)
	    return false;

	m_hThread = hThread;
	m_idThread = threadId;
	ResumeThread(hThread);

	return true;
    }

protected:
    virtual unsigned Run() = 0;

private:
    static unsigned __stdcall StaticThreadRoutine(void *pParam)
    {
	return static_cast<Thread *>(pParam)->Run();
    }
};

class TaskThread : public Thread
{
public:
    virtual unsigned Run()
    {
	Task task(NULL);
	task.Run();

	return 0;
    }
};

void CBgthreadDlg::OnBackground() 
{
    // Run on a background thread.  Don't wait for the thread to exit.
    TaskThread t;
    t.Start();
}
